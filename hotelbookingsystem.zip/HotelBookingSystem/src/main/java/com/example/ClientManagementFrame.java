package com.example;

import javax.swing.*; // Импортируем необходимые классы из библиотеки Swing
import java.awt.*; // Импортируем классы для работы с графическим интерфейсом
import java.awt.event.ActionEvent; // Импортируем классы для работы с событиями
import java.awt.event.ActionListener; // Импортируем интерфейс для обработки действий
import java.util.List; // Импортируем классы для работы со списками

public class ClientManagementFrame extends JFrame {
    private DatabaseHelper dbHelper; // Экземпляр для работы с базой данных
    private ClientManager clientManager; // Экземпляр менеджера клиентов
    private JList<Client> clientList; // Список для отображения клиентов
    private DefaultListModel<Client> listModel; // Модель списка для управления данными в JList

    public ClientManagementFrame(DatabaseHelper dbHelper) {
        this.dbHelper = dbHelper; // Инициализация базы данных
        this.clientManager = new ClientManager(); // Инициализация менеджера клиентов
        setTitle("Управление клиентами"); // Заголовок окна
        setSize(600, 350); // Размер окна
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Закрытие окна
        setLocationRelativeTo(null); // Центрирование окна на экране

        listModel = new DefaultListModel<>(); // Создание модели списка
        clientList = new JList<>(listModel); // Инициализация списка клиентов
        JScrollPane scrollPane = new JScrollPane(clientList); // Добавление прокрутки к списку

        // Поля для ввода имени и email клиента
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();

        // Кнопки управления
        JButton addButton = new JButton("Добавить");
        JButton deleteButton = new JButton("Удалить");
        JButton loadButton = new JButton("Загрузить клиентов");

        // Обработчик загрузки клиентов
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadClients(); // Вызов метода загрузки клиентов
            }
        });

        // Обработчик добавления клиента
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText(); // Получение имени из поля ввода
                String email = emailField.getText(); // Получение email из поля ввода
                clientManager.addClient(name, email, dbHelper); // Добавление клиента
                loadClients(); // Обновление списка клиентов
                nameField.setText(""); // Очистка поля имени
                emailField.setText(""); // Очистка поля email
            }
        });

        // Обработчик удаления клиента
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Client selectedClient = clientList.getSelectedValue(); // Получение выбранного клиента
                if (selectedClient != null) {
                    clientManager.deleteClient(selectedClient.getId(), dbHelper); // Удаление клиента
                    loadClients(); // Обновление списка клиентов
                } else {
                    // Показать сообщение об ошибке, если клиент не выбран
                    JOptionPane.showMessageDialog(ClientManagementFrame.this,
                            "Выберите клиента для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Панель для ввода данных клиента и кнопок управления
        JPanel inputPanel = new JPanel(new GridLayout(3, 2)); // Сетка для расположения компонентов
        inputPanel.add(new JLabel("Имя:")); // Метка для имени
        inputPanel.add(nameField); // Поле ввода имени
        inputPanel.add(new JLabel("Email:")); // Метка для email
        inputPanel.add(emailField); // Поле ввода email
        inputPanel.add(addButton); // Кнопка добавления
        inputPanel.add(deleteButton); // Кнопка удаления

        // Добавление компонентов в окно
        add(scrollPane, BorderLayout.CENTER); // Добавление списка клиентов
        add(inputPanel, BorderLayout.SOUTH); // Добавление панели ввода
        add(loadButton, BorderLayout.NORTH); // Добавление кнопки загрузки
    }

    // Метод для загрузки клиентов в список
    private void loadClients() {
        listModel.clear(); // Очистка списка перед загрузкой
        List<Client> clients = clientManager.getAllClients(dbHelper); // Получение всех клиентов
        for (Client client : clients) {
            listModel.addElement(client); // Добавление клиентов в модель списка
        }
    }
}
