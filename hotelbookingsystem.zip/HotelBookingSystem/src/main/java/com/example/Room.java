package com.example; // Указываем пакет, в котором находится класс

public class Room { // Класс для представления комнаты
    private int id; // Идентификатор комнаты
    private int number; // Номер комнаты
    private String type; // Тип комнаты (например, "одноместный", "двухместный")
    private double price; // Цена за ночь

    // Конструктор для инициализации объекта Room
    public Room(int id, int number, String type, double price) {
        this.id = id; // Установка ID комнаты
        this.number = number; // Установка номера комнаты
        this.type = type; // Установка типа комнаты
        this.price = price; // Установка цены
    }

    // Геттеры и сеттеры для доступа к полям

    public int getId() {
        return id; // Возвращает ID комнаты
    }

    public void setId(int id) {
        this.id = id; // Устанавливает ID комнаты
    }

    public int getNumber() {
        return number; // Возвращает номер комнаты
    }

    public void setNumber(int number) {
        this.number = number; // Устанавливает номер комнаты
    }

    public String getType() {
        return type; // Возвращает тип комнаты
    }

    public void setType(String type) {
        this.type = type; // Устанавливает тип комнаты
    }

    public double getPrice() {
        return price; // Возвращает цену за ночь
    }

    public void setPrice(double price) {
        this.price = price; // Устанавливает цену за ночь
    }

    @Override
    public String toString() {
        // Форматирует строку для отображения информации о комнате
        return "ID: " + id + ", Room " + number + " (" + type + ") - $" + price;
    }
}
