package com.example; // Указываем пакет, в котором находится класс

import java.sql.Date; // Импортируем класс Date для работы с датами

public class Reservation { // Класс Reservation для представления резервирования
    private int id; // Идентификатор резервации
    private int clientId; // Идентификатор клиента, связанного с резервированием
    private int roomId; // Идентификатор комнаты, которая была забронирована
    private Date checkIn; // Дата заезда
    private Date checkOut; // Дата выезда

    public Reservation(int id, int clientId, int roomId, Date checkIn, Date checkOut) { // Конструктор класса
        this.id = id; // Инициализация идентификатора резервации
        this.clientId = clientId; // Инициализация идентификатора клиента
        this.roomId = roomId; // Инициализация идентификатора комнаты
        this.checkIn = checkIn; // Инициализация даты заезда
        this.checkOut = checkOut; // Инициализация даты выезда
    }

    // Геттеры и сеттеры для доступа к полям класса

    public int getId() {
        return id; // Возвращает идентификатор резервации
    }

    public void setId(int id) {
        this.id = id; // Устанавливает идентификатор резервации
    }

    public int getClientId() {
        return clientId; // Возвращает идентификатор клиента
    }

    public void setClientId(int clientId) {
        this.clientId = clientId; // Устанавливает идентификатор клиента
    }

    public int getRoomId() {
        return roomId; // Возвращает идентификатор комнаты
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId; // Устанавливает идентификатор комнаты
    }

    public Date getCheckIn() {
        return checkIn; // Возвращает дату заезда
    }

    public void setCheckIn(Date checkIn) {
        this.checkIn = checkIn; // Устанавливает дату заезда
    }

    public Date getCheckOut() {
        return checkOut; // Возвращает дату выезда
    }

    public void setCheckOut(Date checkOut) {
        this.checkOut = checkOut; // Устанавливает дату выезда
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Reservation [ID: " + id + ", Client ID: " + clientId + ", Room ID: " + roomId +
                ", Check-in: " + checkIn + ", Check-out: " + checkOut + "]"; // Форматирование строки для отображения информации о резервировании
    }
}
