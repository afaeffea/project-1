package com.example; // Указываем пакет, в котором находится класс

import com.example.DatabaseHelper; // Импортируем класс для работы с базой данных
import javax.swing.*; // Импортируем все классы из библиотеки Swing для создания GUI
import java.awt.*; // Импортируем классы для работы с графикой
import java.awt.event.ActionEvent; // Импортируем класс для обработки событий действий
import java.awt.event.ActionListener; // Импортируем интерфейс для слушателей событий

public class HotelBookingGUI extends JFrame { // Класс HotelBookingGUI расширяет JFrame для создания главного окна
    private DatabaseHelper dbHelper; // Переменная для хранения экземпляра DatabaseHelper

    public HotelBookingGUI() { // Конструктор класса
        dbHelper = new DatabaseHelper(); // Инициализация базы данных

        setTitle("Система бронирования гостиницы"); // Установка заголовка окна
        setSize(600, 400); // Увеличен размер окна
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Завершение приложения при закрытии окна
        setLocationRelativeTo(null); // Центрирование окна на экране

        // Главное меню
        JMenuBar menuBar = new JMenuBar(); // Создание панели меню

        // Меню "Клиенты"
        JMenu clientMenu = new JMenu("Клиенты");
        JMenuItem clientItem = new JMenuItem("Управление клиентами"); // Элемент меню для управления клиентами
        clientItem.addActionListener(new ActionListener() { // Обработчик событий для клика по элементу
            @Override
            public void actionPerformed(ActionEvent e) {
                new ClientManagementFrame(dbHelper).setVisible(true); // Открытие окна управления клиентами
            }
        });
        clientMenu.add(clientItem); // Добавление элемента в меню
        menuBar.add(clientMenu); // Добавление меню клиентов в панель меню

        // Меню "Комнаты"
        JMenu roomMenu = new JMenu("Комнаты");
        JMenuItem roomItem = new JMenuItem("Управление комнатами"); // Элемент меню для управления комнатами
        roomItem.addActionListener(new ActionListener() { // Обработчик событий
            @Override
            public void actionPerformed(ActionEvent e) {
                new RoomManagementFrame(dbHelper).setVisible(true); // Открытие окна управления комнатами
            }
        });
        roomMenu.add(roomItem); // Добавление элемента в меню
        menuBar.add(roomMenu); // Добавление меню комнат в панель меню

        // Меню "Брони"
        JMenu reservationMenu = new JMenu("Брони");
        JMenuItem reservationItem = new JMenuItem("Управление бронями"); // Элемент меню для управления бронями
        reservationItem.addActionListener(new ActionListener() { // Обработчик событий
            @Override
            public void actionPerformed(ActionEvent e) {
                new ReservationManagementFrame(dbHelper).setVisible(true); // Открытие окна управления бронями
            }
        });
        reservationMenu.add(reservationItem); // Добавление элемента в меню
        menuBar.add(reservationMenu); // Добавление меню броней в панель меню

        setJMenuBar(menuBar); // Установка меню на фрейм

        // Добавление изображения по центру
        ImageIcon imageIcon = new ImageIcon("src/main/resources/logo.jpg"); // Загрузка изображения (укажите путь к вашему изображению)
        JLabel imageLabel = new JLabel(imageIcon); // Создание JLabel с загруженным изображением
        imageLabel.setHorizontalAlignment(JLabel.CENTER); // Центрирование изображения

        // Панель для размещения изображения
        JPanel imagePanel = new JPanel(); // Создание новой панели
        imagePanel.setLayout(new BorderLayout()); // Установка менеджера компоновки BorderLayout
        imagePanel.add(imageLabel, BorderLayout.CENTER); // Добавляем JLabel с изображением в центр панели

        // Добавляем панель с изображением в основной фрейм
        add(imagePanel, BorderLayout.CENTER); // Добавление панели в центр основного окна

        setVisible(true); // Отображение окна
    }

    public static void main(String[] args) { // Главный метод для запуска приложения
        SwingUtilities.invokeLater(() -> new HotelBookingGUI()); // Запуск графического интерфейса в потоке обработки событий
    }
}
