package com.example;

import java.sql.Connection; // Импортируем класс для работы с соединениями к базе данных
import java.sql.PreparedStatement; // Импортируем класс для подготовки SQL-запросов
import java.sql.ResultSet; // Импортируем класс для работы с результатами SQL-запросов
import java.sql.SQLException; // Импортируем класс для обработки исключений SQL
import java.util.ArrayList; // Импортируем класс для работы с динамическими массивами
import java.util.List; // Импортируем класс для работы со списками

public class ClientManager {
    // Метод для добавления клиента
    public void addClient(String name, String email, DatabaseHelper dbHelper) {
        try (Connection conn = dbHelper.getConnection()) { // Устанавливаем соединение с базой данных
            String sql = "INSERT INTO clients (name, email) VALUES (?, ?)"; // SQL-запрос на добавление клиента
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка SQL-запроса
            pstmt.setString(1, name); // Установка имени клиента
            pstmt.setString(2, email); // Установка email клиента
            pstmt.executeUpdate(); // Выполнение обновления в базе данных
        } catch (SQLException e) {
            System.out.println("Ошибка при добавлении клиента: " + e.getMessage()); // Обработка ошибок
        }
    }

    // Метод для удаления клиента
    public void deleteClient(int clientId, DatabaseHelper dbHelper) {
        try (Connection conn = dbHelper.getConnection()) { // Устанавливаем соединение с базой данных
            String sql = "DELETE FROM clients WHERE id = ?"; // SQL-запрос на удаление клиента
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка SQL-запроса
            pstmt.setInt(1, clientId); // Установка ID клиента
            pstmt.executeUpdate(); // Выполнение обновления в базе данных
        } catch (SQLException e) {
            System.out.println("Ошибка при удалении клиента: " + e.getMessage()); // Обработка ошибок
        }
    }

    // Метод для получения всех клиентов
    public List<Client> getAllClients(DatabaseHelper dbHelper) {
        List<Client> clients = new ArrayList<>(); // Список для хранения клиентов
        try (Connection conn = dbHelper.getConnection()) { // Устанавливаем соединение с базой данных
            String sql = "SELECT * FROM clients"; // SQL-запрос на получение всех клиентов
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка SQL-запроса
            ResultSet rs = pstmt.executeQuery(); // Выполнение запроса и получение результата

            // Цикл для обработки результатов
            while (rs.next()) {
                int id = rs.getInt("id"); // Получение ID клиента
                String name = rs.getString("name"); // Получение имени клиента
                String email = rs.getString("email"); // Получение email клиента
                clients.add(new Client(id, name, email)); // Создание объекта клиента и добавление в список
            }
        } catch (SQLException e) {
            System.out.println("Ошибка при получении клиентов: " + e.getMessage()); // Обработка ошибок
        }
        return clients; // Возврат списка клиентов
    }
}
