package com.example;

import java.sql.Connection; // Импортируем класс для работы с соединениями к базе данных
import java.sql.DriverManager; // Импортируем класс для управления драйверами JDBC
import java.sql.SQLException; // Импортируем класс для обработки исключений SQL
import java.sql.Statement; // Импортируем класс для выполнения SQL-запросов

public class DatabaseHelper {
    private final String DATABASE_URL = "jdbc:sqlite:hotel_booking.db"; // URL для подключения к базе данных SQLite

    public DatabaseHelper() {
        createDatabaseAndTables(); // Вызов метода для создания базы данных и таблиц при инициализации
    }

    // Метод для создания базы данных и таблиц
    private void createDatabaseAndTables() {
        try (Connection conn = DriverManager.getConnection(DATABASE_URL)) { // Устанавливаем соединение с базой данных
            if (conn != null) { // Проверяем, успешно ли установлено соединение
                String createClientsTable = "CREATE TABLE IF NOT EXISTS clients (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," + // Автоинкрементируемый ID клиента
                        "name TEXT NOT NULL," + // Имя клиента
                        "email TEXT NOT NULL UNIQUE);"; // Уникальный email клиента

                String createRoomsTable = "CREATE TABLE IF NOT EXISTS rooms (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," + // Автоинкрементируемый ID комнаты
                        "number INTEGER NOT NULL UNIQUE," + // Уникальный номер комнаты
                        "type TEXT NOT NULL," + // Тип комнаты
                        "price REAL NOT NULL);"; // Цена комнаты

                String createReservationsTable = "CREATE TABLE IF NOT EXISTS reservations (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," + // Автоинкрементируемый ID бронирования
                        "client_id INTEGER NOT NULL," + // ID клиента (внешний ключ)
                        "room_id INTEGER NOT NULL," + // ID комнаты (внешний ключ)
                        "check_in DATE NOT NULL," + // Дата заезда
                        "check_out DATE NOT NULL," + // Дата выезда
                        "FOREIGN KEY (client_id) REFERENCES clients(id)," + // Связь с таблицей клиентов
                        "FOREIGN KEY (room_id) REFERENCES rooms(id));"; // Связь с таблицей комнат

                try (Statement stmt = conn.createStatement()) { // Создаем объект для выполнения SQL-запросов
                    stmt.execute(createClientsTable); // Выполняем создание таблицы клиентов
                    stmt.execute(createRoomsTable); // Выполняем создание таблицы комнат
                    stmt.execute(createReservationsTable); // Выполняем создание таблицы броней
                }
            }
        } catch (SQLException e) {
            System.out.println("Ошибка при создании базы данных: " + e.getMessage()); // Обработка ошибок
        }
    }

    // Метод для получения соединения с базой данных
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL); // Возвращаем соединение с базой данных
    }
}
