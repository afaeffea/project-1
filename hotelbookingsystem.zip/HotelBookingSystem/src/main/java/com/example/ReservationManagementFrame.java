package com.example; // Указываем пакет, в котором находится класс

import javax.swing.*; // Импортируем компоненты Swing для создания GUI
import java.awt.*; // Импортируем классы для работы с графикой
import java.awt.event.ActionEvent; // Импортируем класс для обработки событий
import java.awt.event.ActionListener; // Импортируем интерфейс для слушателей событий
import java.sql.Date; // Импортируем класс Date для работы с датами
import java.util.List; // Импортируем класс List для работы со списками

public class ReservationManagementFrame extends JFrame { // Класс для управления резервированием, наследует JFrame
    private DatabaseHelper dbHelper; // Экземпляр для работы с базой данных
    private ReservationManager reservationManager; // Экземпляр для управления резервированием
    private JList<Reservation> reservationList; // Список для отображения резервирований
    private DefaultListModel<Reservation> listModel; // Модель списка для управления элементами в JList

    public ReservationManagementFrame(DatabaseHelper dbHelper) {
        this.dbHelper = dbHelper; // Инициализация базы данных
        this.reservationManager = new ReservationManager(); // Инициализация менеджера резервирований
        setTitle("Управление бронями"); // Установка заголовка окна
        setSize(600, 350); // Установка размеров окна
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Закрытие окна при выходе
        setLocationRelativeTo(null); // Центрирование окна на экране

        listModel = new DefaultListModel<>(); // Инициализация модели списка
        reservationList = new JList<>(listModel); // Создание списка с моделью
        JScrollPane scrollPane = new JScrollPane(reservationList); // Добавление полосы прокрутки к списку

        // Поля ввода для информации о резервировании
        JTextField clientIdField = new JTextField(); // Поле для ввода ID клиента
        JTextField roomIdField = new JTextField(); // Поле для ввода ID комнаты
        JTextField checkInField = new JTextField("YYYY-MM-DD"); // Поле для ввода даты заезда
        JTextField checkOutField = new JTextField("YYYY-MM-DD"); // Поле для ввода даты выезда
        JButton addButton = new JButton("Добавить"); // Кнопка для добавления резервирования
        JButton deleteButton = new JButton("Удалить"); // Кнопка для удаления резервирования
        JButton loadButton = new JButton("Загрузить бронь"); // Кнопка для загрузки резервирования

        // Обработчик загрузки броней
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadReservations(); // Вызов метода загрузки резервирования
            }
        });

        // Обработчик добавления брони
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Получаем данные из полей ввода
                    int clientId = Integer.parseInt(clientIdField.getText().trim());
                    int roomId = Integer.parseInt(roomIdField.getText().trim());
                    Date checkIn = Date.valueOf(checkInField.getText().trim());
                    Date checkOut = Date.valueOf(checkOutField.getText().trim());

                    // Выполняем добавление брони через менеджер
                    reservationManager.addReservation(clientId, roomId, checkIn, checkOut, dbHelper);

                    // Обновляем список резервирований
                    loadReservations();

                    // Очистка полей ввода после успешного добавления
                    clientIdField.setText("");
                    roomIdField.setText("");
                    checkInField.setText("YYYY-MM-DD");
                    checkOutField.setText("YYYY-MM-DD");

                    // Уведомление об успешном добавлении
                    JOptionPane.showMessageDialog(
                            ReservationManagementFrame.this,
                            "Бронь успешно добавлена!",
                            "Успех",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                } catch (IllegalArgumentException ex) {
                    // Показываем сообщение об ошибке, если есть проблемы с данными
                    JOptionPane.showMessageDialog(
                            ReservationManagementFrame.this,
                            ex.getMessage(),
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE
                    );
                } catch (Exception ex) {
                    // Показываем общее сообщение об ошибке
                    JOptionPane.showMessageDialog(
                            ReservationManagementFrame.this,
                            "Произошла ошибка: " + ex.getMessage(),
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        });


        // Обработчик удаления брони
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Reservation selectedReservation = reservationList.getSelectedValue(); // Получаем выбранное резервирование
                if (selectedReservation != null) {
                    reservationManager.deleteReservation(selectedReservation.getId(), dbHelper); // Удаление резервирования
                    loadReservations(); // Обновление списка резервирований
                } else {
                    // Показ сообщения об ошибке, если ничего не выбрано
                    JOptionPane.showMessageDialog(ReservationManagementFrame.this,
                            "Выберите бронь для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Панель для ввода данных
        JPanel inputPanel = new JPanel(new GridLayout(5, 2)); // Создание панели с сеткой 5x2
        inputPanel.add(new JLabel("ID Клиента:")); // Метка для поля ID клиента
        inputPanel.add(clientIdField); // Поле для ввода ID клиента
        inputPanel.add(new JLabel("ID Комнаты:")); // Метка для поля ID комнаты
        inputPanel.add(roomIdField); // Поле для ввода ID комнаты
        inputPanel.add(new JLabel("Дата заезда:")); // Метка для поля даты заезда
        inputPanel.add(checkInField); // Поле для ввода даты заезда
        inputPanel.add(new JLabel("Дата выезда:")); // Метка для поля даты выезда
        inputPanel.add(checkOutField); // Поле для ввода даты выезда
        inputPanel.add(addButton); // Кнопка добавления
        inputPanel.add(deleteButton); // Кнопка удаления

        // Добавление компонентов в окно
        add(scrollPane, BorderLayout.CENTER); // Список резервирований
        add(inputPanel, BorderLayout.SOUTH); // Панель ввода в нижнюю часть окна
        add(loadButton, BorderLayout.NORTH); // Кнопка загрузки в верхнюю часть окна
    }

    // Метод для загрузки броней в список
    private void loadReservations() {
        listModel.clear(); // Очистка текущего списка
        List<Reservation> reservations = reservationManager.getAllReservations(dbHelper); // Получение всех резервирований
        for (Reservation reservation : reservations) {
            listModel.addElement(reservation); // Добавление резервирования в модель списка
        }
    }
}
