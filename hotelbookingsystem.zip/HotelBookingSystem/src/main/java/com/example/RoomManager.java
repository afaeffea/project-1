package com.example; // Указываем пакет, в котором находится класс

import java.sql.Connection; // Импортируем классы для работы с соединением
import java.sql.PreparedStatement; // Импортируем классы для выполнения подготовленных запросов
import java.sql.ResultSet; // Импортируем классы для работы с результатами запросов
import java.sql.SQLException; // Импортируем классы для обработки исключений SQL
import java.util.ArrayList; // Импортируем классы для работы с массивами
import java.util.List; // Импортируем классы для работы со списками

public class RoomManager { // Класс для управления комнатами

    // Метод для добавления комнаты
    public void addRoom(int number, String type, double price, DatabaseHelper dbHelper) {
        try (Connection conn = dbHelper.getConnection()) { // Установка соединения с базой данных
            String sql = "INSERT INTO rooms (number, type, price) VALUES (?, ?, ?)"; // SQL запрос для добавления комнаты
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка запроса
            pstmt.setInt(1, number); // Установка значения номера комнаты
            pstmt.setString(2, type); // Установка значения типа комнаты
            pstmt.setDouble(3, price); // Установка значения цены комнаты
            pstmt.executeUpdate(); // Выполнение запроса
        } catch (SQLException e) { // Обработка исключений
            System.out.println("Ошибка при добавлении комнаты: " + e.getMessage());
        }
    }

    // Метод для удаления комнаты
    public void deleteRoom(int roomId, DatabaseHelper dbHelper) {
        try (Connection conn = dbHelper.getConnection()) { // Установка соединения с базой данных
            String sql = "DELETE FROM rooms WHERE id = ?"; // SQL запрос для удаления комнаты
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка запроса
            pstmt.setInt(1, roomId); // Установка значения ID комнаты
            pstmt.executeUpdate(); // Выполнение запроса
        } catch (SQLException e) { // Обработка исключений
            System.out.println("Ошибка при удалении комнаты: " + e.getMessage());
        }
    }

    // Метод для получения всех комнат
    public List<Room> getAllRooms(DatabaseHelper dbHelper) {
        List<Room> rooms = new ArrayList<>(); // Создание списка для хранения комнат
        try (Connection conn = dbHelper.getConnection()) { // Установка соединения с базой данных
            String sql = "SELECT * FROM rooms"; // SQL запрос для получения всех комнат
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка запроса
            ResultSet rs = pstmt.executeQuery(); // Выполнение запроса и получение результата

            while (rs.next()) { // Итерация по результатам
                int id = rs.getInt("id"); // Получение ID комнаты
                int number = rs.getInt("number"); // Получение номера комнаты
                String type = rs.getString("type"); // Получение типа комнаты
                double price = rs.getDouble("price"); // Получение цены комнаты
                rooms.add(new Room(id, number, type, price)); // Добавление комнаты в список
            }
        } catch (SQLException e) { // Обработка исключений
            System.out.println("Ошибка при получении комнат: " + e.getMessage());
        }
        return rooms; // Возврат списка комнат
    }
}
