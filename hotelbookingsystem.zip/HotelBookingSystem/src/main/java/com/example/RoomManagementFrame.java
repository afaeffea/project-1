package com.example; // Указываем пакет, в котором находится класс

import javax.swing.*; // Импортируем классы для создания графического интерфейса
import java.awt.*; // Импортируем классы для работы с графическими элементами
import java.awt.event.ActionEvent; // Импортируем классы для обработки событий
import java.awt.event.ActionListener; // Импортируем интерфейс для обработки действий
import java.util.List; // Импортируем классы для работы со списками

public class RoomManagementFrame extends JFrame { // Класс для управления комнатами
    private DatabaseHelper dbHelper; // Объект для доступа к базе данных
    private RoomManager roomManager; // Объект для управления комнатами
    private JList<Room> roomList; // Список для отображения комнат
    private DefaultListModel<Room> listModel; // Модель списка

    public RoomManagementFrame(DatabaseHelper dbHelper) {
        this.dbHelper = dbHelper; // Инициализация базы данных
        this.roomManager = new RoomManager(); // Инициализация менеджера комнат
        setTitle("Управление комнатами"); // Заголовок окна
        setSize(600, 350); // Размер окна
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Действие при закрытии окна
        setLocationRelativeTo(null); // Центрирование окна

        listModel = new DefaultListModel<>(); // Создание модели списка
        roomList = new JList<>(listModel); // Создание списка с моделью
        JScrollPane scrollPane = new JScrollPane(roomList); // Добавление полосы прокрутки

        // Поля для ввода данных о комнате
        JTextField numberField = new JTextField(); // Поле для ввода номера комнаты
        JTextField typeField = new JTextField(); // Поле для ввода типа комнаты
        JTextField priceField = new JTextField(); // Поле для ввода цены
        JButton addButton = new JButton("Добавить"); // Кнопка для добавления комнаты
        JButton deleteButton = new JButton("Удалить"); // Кнопка для удаления комнаты
        JButton loadButton = new JButton("Загрузить комнаты"); // Кнопка для загрузки комнат

        // Обработчик загрузки комнат
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadRooms(); // Вызов метода загрузки комнат
            }
        });

        // Обработчик добавления комнаты
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int number = Integer.parseInt(numberField.getText()); // Получение номера комнаты
                String type = typeField.getText(); // Получение типа комнаты
                double price = Double.parseDouble(priceField.getText()); // Получение цены
                roomManager.addRoom(number, type, price, dbHelper); // Добавление комнаты
                loadRooms(); // Обновление списка комнат
                numberField.setText(""); // Очистка поля номера
                typeField.setText(""); // Очистка поля типа
                priceField.setText(""); // Очистка поля цены
            }
        });

        // Обработчик удаления комнаты
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Room selectedRoom = roomList.getSelectedValue(); // Получение выбранной комнаты
                if (selectedRoom != null) {
                    roomManager.deleteRoom(selectedRoom.getId(), dbHelper); // Удаление комнаты
                    loadRooms(); // Обновление списка комнат
                } else {
                    JOptionPane.showMessageDialog(RoomManagementFrame.this,
                            "Выберите комнату для удаления", "Ошибка", JOptionPane.ERROR_MESSAGE); // Сообщение об ошибке
                }
            }
        });

        // Панель для ввода данных
        JPanel inputPanel = new JPanel(new GridLayout(4, 2)); // Создание панели с сеткой
        inputPanel.add(new JLabel("Номер:")); // Метка для номера
        inputPanel.add(numberField); // Поле для номера
        inputPanel.add(new JLabel("Тип:")); // Метка для типа
        inputPanel.add(typeField); // Поле для типа
        inputPanel.add(new JLabel("Цена:")); // Метка для цены
        inputPanel.add(priceField); // Поле для цены
        inputPanel.add(addButton); // Кнопка добавления
        inputPanel.add(deleteButton); // Кнопка удаления

        // Добавление элементов на фрейм
        add(scrollPane, BorderLayout.CENTER); // Добавление списка комнат
        add(inputPanel, BorderLayout.SOUTH); // Добавление панели ввода
        add(loadButton, BorderLayout.NORTH); // Добавление кнопки загрузки
    }

    // Метод для загрузки комнат в список
    private void loadRooms() {
        listModel.clear(); // Очистка модели списка
        List<Room> rooms = roomManager.getAllRooms(dbHelper); // Получение всех комнат
        for (Room room : rooms) {
            listModel.addElement(room); // Добавление комнаты в модель списка
        }
    }
}
