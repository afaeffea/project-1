package com.example;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Запускаем графический интерфейс в отдельном потоке
        // Это делается для того, чтобы избежать блокировки основного потока,

        SwingUtilities.invokeLater(() -> {
            // Создание экземпляра главного GUI приложения.
            HotelBookingGUI gui = new HotelBookingGUI();
            // Установка видимости GUI в true для отображения окна.
            gui.setVisible(true);
        });
    }
}
