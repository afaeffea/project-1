package com.example; // Указываем пакет, в котором находится класс

import java.sql.Connection; // Импортируем класс для работы с соединением с БД
import java.sql.PreparedStatement; // Импортируем класс для подготовленных выражений
import java.sql.ResultSet; // Импортируем класс для получения результатов запроса
import java.sql.SQLException; // Импортируем класс для обработки исключений SQL
import java.sql.Date; // Импортируем класс Date для работы с датами
import java.util.ArrayList; // Импортируем класс для работы с динамическими массивами
import java.util.List; // Импортируем интерфейс для работы со списками

public class ReservationManager { // Класс для управления резервированием

    // Метод для добавления брони с проверкой существования клиента, комнаты и занятости
    public void addReservation(int clientId, int roomId, Date checkIn, Date checkOut, DatabaseHelper dbHelper) {
        try (Connection conn = dbHelper.getConnection()) {
            // Проверка существования клиента
            String checkClientSql = "SELECT COUNT(*) FROM clients WHERE id = ?";
            try (PreparedStatement checkClientStmt = conn.prepareStatement(checkClientSql)) {
                checkClientStmt.setInt(1, clientId);
                try (ResultSet rs = checkClientStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) == 0) {
                        throw new IllegalArgumentException("Клиент с ID " + clientId + " не существует.");
                    }
                }
            }

            // Проверка существования комнаты
            String checkRoomSql = "SELECT COUNT(*) FROM rooms WHERE id = ?";
            try (PreparedStatement checkRoomStmt = conn.prepareStatement(checkRoomSql)) {
                checkRoomStmt.setInt(1, roomId);
                try (ResultSet rs = checkRoomStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) == 0) {
                        throw new IllegalArgumentException("Комната с ID " + roomId + " не существует.");
                    }
                }
            }

            // Проверка занятости комнаты
            String checkAvailabilitySql = "SELECT COUNT(*) FROM reservations WHERE room_id = ? AND " +
                    "(? BETWEEN check_in AND check_out OR ? BETWEEN check_in AND check_out OR " +
                    "check_in BETWEEN ? AND ?)";
            try (PreparedStatement checkAvailabilityStmt = conn.prepareStatement(checkAvailabilitySql)) {
                checkAvailabilityStmt.setInt(1, roomId);
                checkAvailabilityStmt.setDate(2, checkIn);
                checkAvailabilityStmt.setDate(3, checkOut);
                checkAvailabilityStmt.setDate(4, checkIn);
                checkAvailabilityStmt.setDate(5, checkOut);
                try (ResultSet rs = checkAvailabilityStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        throw new IllegalArgumentException("Комната с ID " + roomId + " занята на указанные даты.");
                    }
                }
            }

            // Добавление брони
            String addReservationSql = "INSERT INTO reservations (client_id, room_id, check_in, check_out) VALUES (?, ?, ?, ?)";
            try (PreparedStatement addReservationStmt = conn.prepareStatement(addReservationSql)) {
                addReservationStmt.setInt(1, clientId);
                addReservationStmt.setInt(2, roomId);
                addReservationStmt.setDate(3, checkIn);
                addReservationStmt.setDate(4, checkOut);
                addReservationStmt.executeUpdate();
                System.out.println("Бронь успешно добавлена!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Метод для удаления брони
    public void deleteReservation(int reservationId, DatabaseHelper dbHelper) {
        try (Connection conn = dbHelper.getConnection()) { // Устанавливаем соединение с базой данных
            String sql = "DELETE FROM reservations WHERE id = ?"; // SQL запрос на удаление
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка SQL запроса
            pstmt.setInt(1, reservationId); // Установка ID резервирования
            pstmt.executeUpdate(); // Выполнение запроса
        } catch (SQLException e) {
            System.out.println("Ошибка при удалении брони: " + e.getMessage()); // Обработка ошибок
        }
    }

    // Метод для получения всех броней
    public List<Reservation> getAllReservations(DatabaseHelper dbHelper) {
        List<Reservation> reservations = new ArrayList<>(); // Список для хранения резервирований
        try (Connection conn = dbHelper.getConnection()) { // Устанавливаем соединение с базой данных
            String sql = "SELECT * FROM reservations"; // SQL запрос на получение всех броней
            PreparedStatement pstmt = conn.prepareStatement(sql); // Подготовка SQL запроса
            ResultSet rs = pstmt.executeQuery(); // Выполнение запроса и получение результата

            while (rs.next()) { // Перебор результатов
                int id = rs.getInt("id"); // Получение ID резервирования
                int clientId = rs.getInt("client_id"); // Получение ID клиента
                int roomId = rs.getInt("room_id"); // Получение ID комнаты
                Date checkIn = rs.getDate("check_in"); // Получение даты заезда
                Date checkOut = rs.getDate("check_out"); // Получение даты выезда
                // Добавление нового объекта Reservation в список
                reservations.add(new Reservation(id, clientId, roomId, checkIn, checkOut));
            }
        } catch (SQLException e) {
            System.out.println("Ошибка при получении броней: " + e.getMessage()); // Обработка ошибок
        }
        return reservations; // Возврат списка резервирований
    }
}
