package com.example;

public class Client {
    // Поля класса для хранения данных клиента
    private int id;        // Идентификатор клиента
    private String name;   // Имя клиента
    private String email;  // Электронная почта клиента

    // Конструктор класса для инициализации полей
    public Client(int id, String name, String email) {
        this.id = id;       // Присваивание идентификатора
        this.name = name;   // Присваивание имени
        this.email = email; // Присваивание электронной почты
    }

    // Геттеры и сеттеры для доступа и изменения полей

    public int getId() {
        return id; // Возвращает идентификатор клиента
    }

    public void setId(int id) {
        this.id = id; // Устанавливает новый идентификатор клиента
    }

    public String getName() {
        return name; // Возвращает имя клиента
    }

    public void setName(String name) {
        this.name = name; // Устанавливает новое имя клиента
    }

    public String getEmail() {
        return email; // Возвращает электронную почту клиента
    }

    public void setEmail(String email) {
        this.email = email; // Устанавливает новую электронную почту клиента
    }

    // Переопределение метода toString для форматирования строки отображения клиента
    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + " (" + email + ")"; // Форматирование строки для отображения
    }
}
