This is a course work on WEB programming in which the frontend and backend are implemented using Vue and Django
