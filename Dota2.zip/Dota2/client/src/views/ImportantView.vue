<script setup>

</script>
<template>
    <div class="container mt-4">
    <div class="text-center mb-4">
        <h3 class="title">Правило сборки</h3>
    </div>
    <div class="quote">
        <p>Сборка с тосом и дагоном</p>

    </div>
    <div class="quote">
        <p>там еще момчик есть</p>
        
    </div>
</div>

</template>

<style scoped>
.title {
    font-weight: bold; /* Делает заголовок жирным */
    font-size: 1.5rem; /* Увеличивает размер шрифта заголовка */
    color: #343a40; /* Цвет заголовка (можно изменить на желаемый) */
}

.quote {
    background-color: #f8f9fa; /* Цвет фона для цитат */
    border-left: 4px solid #007bff; /* Левый бордер для акцента */
    margin: 10px;
    padding: 15px; /* Внутренние отступы */
    border-radius: 5px; /* Скругление углов */
    font-size: 1.1rem; /* Размер шрифта для цитат */
    color: #495057; /* Цвет текста для цитат */
}

.quote p {
    margin: 0; /* Убираем отступы между абзацами */
}

</style>